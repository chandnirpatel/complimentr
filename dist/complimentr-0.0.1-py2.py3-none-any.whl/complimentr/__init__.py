from complimentr.compliments import runComplimentrApp

def main():
  runComplimentrApp()
  return
