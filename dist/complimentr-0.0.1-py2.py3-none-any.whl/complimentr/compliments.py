def main() {
  print("say this instead")
}
